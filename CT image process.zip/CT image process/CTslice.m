function CTslice
D=dicomread('dose1');
D=squeeze(D);
size(D)
figure
for i=1:10
    subplot(2,5,i)
    imagesc(squeeze(D(:,:,i+20)));
end
    