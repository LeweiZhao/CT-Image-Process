function Eg1
% Example 2.7 pp47 of G.Zeng's Book
%P=phantom(64,64);

P=dicomread('PatientCT2d6');

%P=imread('george_yin.jpg');
%P=rgb2gray(P);
angle=linspace(0,179,20);
R=radon(P,angle);
I1=iradon(R,angle);
I2=iradon(R,angle,'linear','none');

I3=iradon(R,angle,'Hann');
subplot(2,2,1),imshow(P,[]),title('Orignial')
subplot(2,2,2),imshow(I1,[]),title('FBP')
subplot(2,2,3),imshow(I2,[]),title('Unfiltered')
subplot(2,2,4),imshow(I3,[]),title('Hann')