function CTpatient
fileFolder=fullfile(pwd,'CTData');
files=dir(fullfile(fileFolder,'*.dcm'));
filesNames={files.name};
N=length(filesNames);
for k=1:N
info=dicominfo(fullfile(fileFolder,filesNames{k}));
X(:,:,1,k)=dicomread(info);
end

D=double(squeeze(X));
imshow3D(D)