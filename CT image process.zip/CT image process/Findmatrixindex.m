function [i,j,k,v]=Findmatrixindex(x,y,z)
fileFolder=fullfile(pwd,'CTData');
files=dir(fullfile(fileFolder,'*.dcm'));
filesNames={files.name};
n=length(filesNames);

info=dicominfo(fullfile(fileFolder,filesNames{n}));

%info=dicominfo('PatientCT2d5');
O=info.ImagePositionPatient;

h=info.PixelSpacing;
h=h(1);
N=info.Width;
N=double(N);
l=h*N;
i=(-10*z-O(2))*N/l;
j=(10*x-O(1))*N/l;
i=round(i);
j=round(j);
k=(10*y-O(3))/3+1;
k=round(k);

Info=dicominfo(fullfile(fileFolder,filesNames{n-k+1}));
M=dicomread(Info);
v=M(i,j);
M(i-10:i+10,j-10:j+10)=0;
imshow(M,[])


