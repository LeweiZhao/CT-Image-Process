function SurfaceCT3D
D=dicomread('dose2');
D=squeeze(D);
p = patch(isosurface(D, 5), 'FaceColor', 'red', 'EdgeColor', 'none');
view(3); 
axis tight; 
daspect([1 1 .4])
colormap(gray(100))
camlight;
lighting gouraud
isonormals(D,p);